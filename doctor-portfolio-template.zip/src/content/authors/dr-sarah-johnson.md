---
name: "Dr. Sarah Johnson"
title: "MD, Internal Medicine"
bio: "Board-certified internal medicine physician with over 15 years of experience in providing comprehensive medical care."
image: "/images/doctors/dr-sarah-johnson.svg"
specialties: ["Internal Medicine", "Preventive Care", "Chronic Disease Management"]
social:
  twitter: "@drsarahjohnson"
  linkedin: "linkedin.com/in/drsarahjohnson"
---
